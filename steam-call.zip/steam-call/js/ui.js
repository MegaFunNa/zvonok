/* ============================================================
   ui.js — плитки видео, раскладки, панели, чат, реакции
   ============================================================ */
import { state, el, esc, toast, initials, hashHue, fmtTime, svg, linkify } from './store.js';
import { setElVolume } from './media.js';

const tiles = new Map();      // key "pid:type" -> {root, video, ph, micIc, ...}
let porder = [];              // порядок участников (без себя)
let lastSpotKey = null;

/* ---------- Хелпер громкости ---------- */
function volKey(pid, type) { return pid + ':' + type; }
function getVol(pid, type) {
  const v = state.ui.vol[volKey(pid, type)];
  return v === undefined ? 100 : v;
}
function saveVol(pid, type, v) { state.ui.vol[volKey(pid, type)] = v; }

function avatarHtml(user, cls = '') {
  if (user.avatar) return `<img src="${esc(user.avatar)}" alt="" class="${cls}" onerror="this.style.display='none'">`;
  return `<span class="ini ${cls}" style="background:hsl(${hashHue(user.name)},35%,42%)">${esc(initials(user.name))}</span>`;
}

/* ============================================================
   ПЛИТКИ
   ============================================================ */
function getTile(pid, type) { return tiles.get(volKey(pid, type)); }

function makeTile(pid, type, user) {
  const isMe = pid === 'me';
  const key = volKey(pid, type);
  const root = document.createElement('div');
  root.className = 'tile' + (type === 'screen' ? ' demo' : '') + (isMe && type === 'main' ? ' local' : '');
  root.id = 't-' + key.replace(':', '-');

  const video = document.createElement('video');
  video.autoplay = true; video.playsInline = true; video.setAttribute('playsinline', '');
  if (isMe) video.muted = true;
  if (isMe && type === 'main' && state.settings.mirror) video.classList.add('mirror');
  root.appendChild(video);

  /* Заглушка */
  const ph = document.createElement('div');
  ph.className = 'ph';
  if (type === 'main') {
    ph.innerHTML = `${avatarHtml(user)}<span class="txt">${isMe ? 'камера выключена' : esc(user.name)}</span>`;
  } else {
    ph.innerHTML = `${svg('monitor', 'ic')}<span class="txt">Демка экрана подключается…</span>`;
  }
  root.appendChild(ph);

  const t = { pid, type, key, root, video, ph, user: { ...user } };

  if (type === 'main') buildMainExtras(t, isMe);
  if (type === 'screen') buildDemoBar(t, isMe);
  tiles.set(key, t);
  return t;
}

function buildMainExtras(t, isMe) {
  /* Плашка имени + микрофон */
  const badge = document.createElement('div');
  badge.className = 'name-badge';
  badge.innerHTML = `<span class="mic-ic">${svg('mic').replace('class="ic"', 'class="mic-ic"')}</span>
    <span class="nm">${isMe ? 'Вы' : esc(t.user.name)}</span>
    ${t.user.steamId ? '<span class="stm" title="Есть SteamID">◉steam</span>' : ''}`;
  t.micIc = badge.querySelector('.mic-ic');
  t.root.appendChild(badge);

  /* Кнопки: закрепить, громкость, PiP, полный экран */
  const ctl = document.createElement('div');
  ctl.className = 'tile-ctl';
  ctl.innerHTML = `
    <button class="b-pin" title="Закрепить плитку">${svg('pin')}</button>
    <button class="b-vol" title="Громкость">${svg('volume')}</button>
    <button class="b-pip" title="Картинка в картинке">${svg('pip')}</button>
    <button class="b-fs" title="Во весь экран">${svg('maximize')}</button>`;
  t.root.appendChild(ctl);

  ctl.querySelector('.b-pin').onclick = () => togglePin(t.pid);
  ctl.querySelector('.b-fs').onclick = () => fullscreenTile(t);
  ctl.querySelector('.b-pip').onclick = () => {
    if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
    else t.video.requestPictureInPicture?.().catch(() => {});
  };
  ctl.querySelector('.b-vol').onclick = () => toggleVolPop(t);
  if (!document.pictureInPictureEnabled) ctl.querySelector('.b-pip').style.display = 'none';
}

function buildDemoBar(t, isMe) {
  const bar = document.createElement('div');
  bar.className = 'demo-bar';
  bar.innerHTML = `
    <span class="tag">${svg('monitor')}Демка · ${isMe ? 'вы' : esc(t.user.name)}</span>
    <div class="vol">${svg('volume')}
      <input type="range" min="0" max="200" value="${getVol(t.pid, 'screen')}" title="Громкость звука демки">
      <output>${getVol(t.pid, 'screen')}%</output>
    </div>
    <span class="grow"></span>
    <button class="b-pip btn" title="Картинка в картинке">${svg('pip')}</button>
    <button class="b-fs btn" title="Демка на весь экран">${svg('maximize')}</button>
    ${isMe ? `<button class="b-stop btn btn-danger">${svg('stop')}Стоп</button>` : ''}`;
  t.root.appendChild(bar);

  const inp = bar.querySelector('input[type=range]');
  const out = bar.querySelector('output');
  inp.addEventListener('input', () => {
    const v = +inp.value;
    out.textContent = v + '%';
    saveVol(t.pid, 'screen', v);
    setElVolume(t.video, v);
  });
  bar.querySelector('.b-fs').onclick = () => fullscreenTile(t);
  bar.querySelector('.b-pip').onclick = () => {
    if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
    else t.video.requestPictureInPicture?.().catch(() => {});
  };
  bar.querySelector('.b-stop')?.addEventListener('click', () => {
    document.dispatchEvent(new CustomEvent('sc:stop-screen'));
  });
  if (!document.pictureInPictureEnabled) bar.querySelector('.b-pip').style.display = 'none';
  if (isMe) { t.video.muted = true; }
}

function fullscreenTile(t) {
  const fn = t.root.requestFullscreen || t.root.webkitRequestFullscreen;
  if (!fn) { toast('Полный экран недоступен в этом браузере', 'err'); return; }
  const cur = document.fullscreenElement || document.webkitFullscreenElement;
  if (cur === t.root) {
    (document.exitFullscreen || document.webkitExitFullscreen)?.call(document).catch?.(() => {});
    return;
  }
  if (cur) {
    const done = () => { try { fn.call(t.root); } catch {} };
    const p = (document.exitFullscreen || document.webkitExitFullscreen)?.call(document);
    if (p && p.then) p.then(done).catch(done); else setTimeout(done, 200);
  } else {
    try { fn.call(t.root); } catch {}
  }
}

function toggleVolPop(t) {
  let pop = t.root.querySelector('.vol-pop');
  if (pop) { pop.remove(); return; }
  pop = document.createElement('div');
  pop.className = 'vol-pop';
  const v = getVol(t.pid, 'main');
  pop.innerHTML = `${svg('volume')}
    <input type="range" min="0" max="200" value="${v}" style="width:120px">
    <output>${v}%</output>
    <button class="b-mute" style="width:28px;height:28px;border:none;border-radius:6px;background:transparent;color:var(--muted);cursor:pointer">${svg('volume-x')}</button>`;
  t.root.appendChild(pop);
  const inp = pop.querySelector('input');
  const out = pop.querySelector('output');
  inp.addEventListener('input', () => {
    out.textContent = inp.value + '%';
    saveVol(t.pid, 'main', +inp.value);
    setElVolume(t.video, +inp.value);
  });
  pop.querySelector('.b-mute').onclick = () => {
    const cur = getVol(t.pid, 'main');
    const nv = cur > 0 ? 0 : 100;
    inp.value = nv; out.textContent = nv + '%';
    saveVol(t.pid, 'main', nv);
    setElVolume(t.video, nv);
  };
  setTimeout(() => {
    const closer = (e) => {
      if (!pop.contains(e.target) && !t.root.contains(e.target)) { pop.remove(); document.removeEventListener('pointerdown', closer); }
    };
    document.addEventListener('pointerdown', closer);
  }, 30);
}

/* ============================================================
   УЧАСТНИКИ
   ============================================================ */
export function ensureParticipant(p) {
  /* p: {pid, user, mic, cam, sharing, ts} */
  let t = getTile(p.pid, 'main');
  if (!t) {
    t = makeTile(p.pid, 'main', p.user);
    if (p.pid !== 'me' && !porder.includes(p.pid)) porder.push(p.pid);
  }
  setParticipantState(p.pid, { mic: p.mic, cam: p.cam });
  if (p.sharing) setSharing(p.pid, true);
  updateLayout();
  updatePeopleList();
  updateRoombar();
  return t;
}

export function removeParticipant(pid) {
  for (const type of ['main', 'screen']) {
    const key = volKey(pid, type);
    const t = tiles.get(key);
    if (t) {
      t.video.srcObject = null;
      t.root.remove();
      tiles.delete(key);
    }
  }
  porder = porder.filter((x) => x !== pid);
  if (state.ui.pinned === pid) state.ui.pinned = null;
  updateLayout();
  updatePeopleList();
  updateRoombar();
}

export function reconcileMembers(list) {
  /* list: [{id, user, mic, cam, sharing, ts}] без меня */
  const ids = new Set(list.map((m) => m.id));
  for (const pid of [...state.room.members.keys()]) {
    if (!ids.has(pid)) removeParticipant(pid);
  }
  for (const m of list) {
    const known = state.room.members.get(m.id);
    if (!known) state.room.members.set(m.id, { ...m });
    else Object.assign(known, m);
    ensureParticipant(m);
    if (m.sharing && !getTile(m.id, 'screen')) {
      /* демка идёт, но поток ещё не пришёл — плитка-заглушка */
      setSharing(m.id, true);
    }
  }
}

export function setParticipantState(pid, patch) {
  const t = getTile(pid, 'main');
  if (!t) return;
  if (patch.mic !== undefined) {
    t.micIc.classList.toggle('off', patch.mic === false);
    t.micIc.innerHTML = (patch.mic === false
      ? `<svg class="mic-ic off" viewBox="0 0 24 24"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`
      : `<svg class="mic-ic" viewBox="0 0 24 24"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`);
  }
  if (patch.cam !== undefined) {
    const hasVideo = t.video.srcObject && t.video.srcObject.getVideoTracks().some((tr) => tr.readyState === 'live');
    t.ph.hidden = !!(patch.cam && hasVideo);
  }
}

export function setSharing(pid, on) {
  const p = pid === 'me' ? { user: state.me } : state.room.members.get(pid);
  if (on && !getTile(pid, 'screen') && p) {
    makeTile(pid, 'screen', p.user);
    updateLayout();
  } else if (!on) {
    const t = getTile(pid, 'screen');
    if (t) { t.video.srcObject = null; t.root.remove(); tiles.delete(volKey(pid, 'screen')); }
    updateLayout();
  }
  updatePeopleList();
}

export function setNetState(pid, type, ok) {
  const t = getTile(pid, type);
  if (t) t.root.classList.toggle('net-bad', !ok);
}

export function setSpeaking(pid, on) {
  if (pid === 'me') {
    el('btnMic')?.classList.toggle('speak', on);
    return;
  }
  const t = getTile(pid, 'main');
  if (t) t.root.classList.toggle('speaking', on);
  if (on) state.ui.activeSpeaker = pid;
  else if (state.ui.activeSpeaker === pid) state.ui.activeSpeaker = null;
  if (on && state.ui.layout === 'spot') updateLayout();
}

/* ============================================================
   ПОТОКИ
   ============================================================ */
export function attachStream(pid, stream, type) {
  const t = getTile(pid, type);
  if (!t) return;
  try { t.video.srcObject = stream; } catch { return; }
  if (type === 'screen') {
    const hasAudio = stream.getAudioTracks().length > 0;
    t.root.classList.toggle('no-audio', !hasAudio);
    t.ph.hidden = true;
    if (hasAudio && pid !== 'me') setElVolume(t.video, getVol(pid, 'screen'));
    if (pid === 'me') t.video.muted = true;
  } else {
    const hasVideo = stream.getVideoTracks().some((tr) => tr.readyState === 'live');
    if (pid !== 'me' && t.user && t.user.cam !== false) t.ph.hidden = hasVideo;
    if (pid === 'me') t.video.muted = true;
    else setElVolume(t.video, getVol(pid, 'main'));
  }
  t.video.play?.().catch(() => {});
  t.root.classList.remove('net-bad');
}

export function setLocalMirror(on) {
  const t = getTile('me', 'main');
  if (t) t.video.classList.toggle('mirror', on);
}

export function showOwnCamState(on) {
  const t = getTile('me', 'main');
  if (t) t.ph.hidden = !!on;
}

/* ============================================================
   РАСКЛАДКА
   ============================================================ */
export function updateLayout() {
  const stage = el('stage');
  const spot = state.ui.layout === 'spot';
  stage.classList.toggle('spot', spot);
  el('spotMain').hidden = !spot;
  el('spotStrip').hidden = !spot;

  const list = [];
  const myMain = getTile('me', 'main');
  if (myMain) list.push(myMain);
  if (state.sharing) { const s = getTile('me', 'screen'); if (s) list.push(s); }
  for (const pid of porder) {
    const m = state.room.members.get(pid);
    const t = getTile(pid, 'main');
    if (t) list.push(t);
    if (m && m.sharing) { const s = getTile(pid, 'screen'); if (s) list.push(s); }
  }

  if (!spot) {
    list.forEach((t) => el('grid').appendChild(t.root));
    lastSpotKey = null;
    return;
  }

  /* Выбор главной плитки */
  let mainT = null;
  if (state.ui.pinned) {
    mainT = getTile(state.ui.pinned, 'screen') || getTile(state.ui.pinned, 'main');
  }
  if (!mainT) mainT = list.find((t) => t.type === 'screen') || null;
  if (!mainT && state.ui.activeSpeaker) mainT = getTile(state.ui.activeSpeaker, 'main');
  if (!mainT) mainT = list[0] || null;

  const key = mainT ? mainT.key : '';
  if (key !== lastSpotKey) lastSpotKey = key;
  for (const t of list) {
    (t === mainT ? el('spotMain') : el('spotStrip')).appendChild(t.root);
  }
}

export function togglePin(pid) {
  state.ui.pinned = state.ui.pinned === pid ? null : pid;
  document.querySelectorAll('.tile .b-pin').forEach((b) => b.classList.remove('on'));
  if (state.ui.pinned) {
    for (const type of ['main', 'screen']) {
      const t = getTile(pid, type);
      t?.root.querySelector('.b-pin')?.classList.add('on');
    }
    toastPin(state.ui.pinned);
  }
  updateLayout();
}
function toastPin() { /* тихо */ }

/* ============================================================
   ВЕРХНЯЯ ПАНЕЛЬ / УПРАВЛЕНИЕ
   ============================================================ */
export function updateRoombar() {
  el('roomCode').textContent = state.room.code || '······';
  const n = state.room.members.size + 1;
  el('peopleCount').textContent = n + ' ' + plural(n, 'участник', 'участника', 'участников');
}
function plural(n, a, b, c) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return a;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return b;
  return c;
}

export function setControlsState() {
  const mic = el('btnMic'), cam = el('btnCam'), scr = el('btnScreen');
  mic.className = 'ctl' + (state.me.mic ? ' on' : ' off');
  mic.innerHTML = svg(state.me.mic ? 'mic' : 'mic-off');
  cam.className = 'ctl' + (state.me.cam ? ' on' : ' off');
  cam.innerHTML = svg(state.me.cam ? 'video' : 'video-off');
  scr.className = 'ctl' + (state.sharing ? ' on' : '');
  scr.innerHTML = svg(state.sharing ? 'monitor-off' : 'monitor');
  scr.title = state.sharing ? 'Остановить демку — клавиша S' : 'Демонстрация экрана — клавиша S';
}

export function setNetBadge(show) {
  el('netBadge').hidden = !show;
}

/* ============================================================
   ЧАТ
   ============================================================ */
export function addChat(m, mine) {
  const list = el('chatList');
  const div = document.createElement('div');
  div.className = 'msg' + (mine ? ' mine' : '');
  div.innerHTML = `
    <div class="meta">${m.avatar ? `<img src="${esc(m.avatar)}" alt="">` : ''}
      <span class="who">${esc(m.name)}</span><span>${fmtTime(m.ts)}</span></div>
    <div class="bubble">${linkify(esc(m.text))}</div>`;
  list.appendChild(div);
  list.scrollTop = list.scrollHeight;
  if (!mine && state.ui.side !== 'chat') {
    state.ui.unread++;
    const b = el('chatBadge');
    b.hidden = false; b.textContent = state.ui.unread > 99 ? '99+' : state.ui.unread;
  }
}

export function sysMsg(text) {
  const list = el('chatList');
  const div = document.createElement('div');
  div.className = 'msg sys';
  div.textContent = text;
  list.appendChild(div);
  list.scrollTop = list.scrollHeight;
}

export function clearUnread() {
  state.ui.unread = 0;
  el('chatBadge').hidden = true;
}

/* ============================================================
   ЛЮДИ
   ============================================================ */
export function updatePeopleList() {
  const box = el('peopleList');
  if (!box) return;
  const rows = [];
  const mkRow = (pid, user, sub, mic, sharing) => {
    const steam = user.steamId
      ? `<a class="stm" href="https://steamcommunity.com/profiles/${esc(user.steamId)}" target="_blank" rel="noopener" title="Открыть профиль Steam">◉ steam</a>` : '';
    return `<div class="p-row" data-pid="${esc(pid)}">
      ${avatarHtml(user)}
      <div class="info"><div class="nm">${pid === 'me' ? 'Вы' : esc(user.name)} ${steam}</div>
      <div class="sub">${sub}</div></div>
      <div class="ctl-mini">
        ${pid !== 'me' ? `<button class="pm" title="Локально заглушить">${svg('volume-x')}</button>` : ''}
      </div></div>`;
  };
  const subMe = [
    state.me.mic ? 'микрофон вкл' : 'микрофон выкл',
    state.me.cam ? 'камера вкл' : 'камера выкл',
    state.sharing ? 'демка идёт' : '',
  ].filter(Boolean).join(' · ');
  rows.push(mkRow('me', state.me, subMe, state.me.mic, state.sharing));
  for (const [pid, p] of state.room.members) {
    const sub = [
      p.mic ? 'микрофон вкл' : 'микрофон выкл',
      p.sharing ? 'демка идёт' : '',
    ].filter(Boolean).join(' · ');
    rows.push(mkRow(pid, p.user, sub, p.mic, p.sharing));
  }
  box.innerHTML = rows.join('');
  box.querySelectorAll('.p-row').forEach((row) => {
    const pid = row.dataset.pid;
    const btn = row.querySelector('.pm');
    if (btn) {
      const t = () => getTile(pid, 'main');
      const paint = () => { btn.classList.toggle('vol-open', getVol(pid, 'main') === 0); };
      paint();
      btn.onclick = () => {
        const cur = getVol(pid, 'main');
        const nv = cur > 0 ? 0 : 100;
        saveVol(pid, 'main', nv);
        const tl = t();
        if (tl) setElVolume(tl.video, nv);
        paint();
      };
    }
  });
}

/* ============================================================
   РЕАКЦИИ
   ============================================================ */
export function spawnReaction(emoji, name) {
  const layer = el('reactions');
  const d = document.createElement('div');
  d.className = 'reaction';
  d.textContent = emoji;
  d.style.left = (8 + Math.random() * 78) + '%';
  d.style.setProperty('--rot', (Math.random() * 40 - 20) + 'deg');
  layer.appendChild(d);
  setTimeout(() => d.remove(), 3100);
  if (name) sysMsg(`${name} ${emoji}`);
}

/* ============================================================
   ПЕРЕКЛЮЧЕНИЕ ЭКРАНОВ
   ============================================================ */
export function showRoom() {
  el('lobby').hidden = true;
  el('room').hidden = false;
  updateRoombar();
  setControlsState();
  sysMsg('Ты в комнате. Отправь ссылку другу через кнопку «Пригласить»!');
}

export function showLobby() {
  el('room').hidden = true;
  el('lobby').hidden = false;
}

export function resetRoomUI() {
  for (const t of tiles.values()) { t.video.srcObject = null; t.root.remove(); }
  tiles.clear();
  porder = [];
  lastSpotKey = null;
  state.room.members.clear();
  state.ui.pinned = null;
  state.ui.activeSpeaker = null;
  state.ui.unread = 0;
  el('chatBadge').hidden = true;
  el('chatList').innerHTML = '';
  el('grid').innerHTML = '';
  el('spotMain').innerHTML = '';
  el('spotStrip').innerHTML = '';
  el('side').hidden = true;
  state.ui.side = null;
  state.ui.layout = 'grid';
  el('stage').classList.remove('spot');
  setNetBadge(false);
}
/* ===== КОНЕЦ ===== */
