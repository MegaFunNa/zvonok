/* ============================================================
   main.js — запуск: лобби, кнопки, модалки, Steam, клавиши
   ============================================================ */
import {
  state, el, on, toast, copyText, lsGet, lsSet,
  injectIcons, parseSteamId, inviteText, roomLink, esc,
} from './store.js';
import * as ui from './ui.js';
import * as media from './media.js';
import * as room from './room.js';

/* ============ ЗАПУСК ============ */
injectIcons();
restoreProfile();
prefillFromUrl();
bindLobby();
bindRoomControls();
bindModals();
bindKeyboard();

document.addEventListener('pointerdown', () => media.unlockAudio(), { once: true });
window.addEventListener('beforeunload', () => room.leaveRoom(true));

if (!window.Peer) {
  toast('Не загрузилась WebRTC-библиотека (CDN). Проверь интернет или отключи блокировщик.', 'err', 10000);
}

/* ============ ПРОФИЛЬ ============ */
function restoreProfile() {
  const p = lsGet('sc_profile', {});
  state.me.name = p.name || '';
  state.me.avatar = p.avatar || '';
  state.me.steamId = p.steamId || '';
  const s = lsGet('sc_settings', {});
  Object.assign(state.settings, s);
  el('inpName').value = state.me.name;
  el('inpAvatar').value = state.me.avatar;
  el('inpSteam').value = state.me.steamId;
  paintAvatarPreview();
}

function saveProfile() {
  lsSet('sc_profile', { name: state.me.name, avatar: state.me.avatar, steamId: state.me.steamId });
}

function paintAvatarPreview() {
  const img = el('avatarPreview');
  const ini = el('avatarInitial');
  if (state.me.avatar) {
    img.src = state.me.avatar;
    img.hidden = false;
    img.onerror = () => { img.hidden = true; ini.hidden = false; };
    ini.hidden = true;
  } else {
    img.hidden = true;
    ini.hidden = false;
    ini.textContent = state.me.name ? [...state.me.name.trim()][0].toUpperCase() : '?';
  }
}

function prefillFromUrl() {
  const code = new URLSearchParams(location.search).get('room');
  if (code) {
    el('inpCode').value = code.toUpperCase();
    el('lobbyHint').hidden = false;
    el('hintCode').textContent = code.toUpperCase();
  }
}

/* ============ ЛОББИ ============ */
function bindLobby() {
  el('inpName').addEventListener('input', () => { state.me.name = el('inpName').value.trim(); paintAvatarPreview(); });
  el('inpAvatar').addEventListener('input', () => { state.me.avatar = el('inpAvatar').value.trim(); paintAvatarPreview(); });
  el('inpSteam').addEventListener('input', () => { state.me.steamId = el('inpSteam').value.trim(); });
  el('inpCode').addEventListener('input', () => { el('inpCode').value = el('inpCode').value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });

  on('btnCreate', 'click', () => startCall(true));
  on('btnJoin', 'click', () => startCall(false));
  el('inpCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') startCall(false); });
  el('inpName').addEventListener('keydown', (e) => { if (e.key === 'Enter') startCall(true); });
}

async function startCall(create) {
  if (!state.me.name) { toast('Введи имя — друзья должны знать, кто ты :)', 'err'); el('inpName').focus(); return; }
  if (!create && !el('inpCode').value) { toast('Введи код комнаты', 'err'); el('inpCode').focus(); return; }
  if (!window.Peer) { toast('WebRTC-библиотека не загрузилась — проверь интернет', 'err'); return; }
  saveProfile();
  el('lobbySpinner').hidden = false;
  try {
    await media.initLocal();
    if (state.localStream) {
      media.watchLevel('me', state.localStream, (act) => ui.setSpeaking('me', act));
    }
    ui.resetRoomUI();
    /* плитка «Вы» */
    ui.ensureParticipant({ pid: 'me', user: { ...state.me }, mic: state.me.mic, cam: state.me.cam, sharing: false, ts: 0 });
    if (state.localStream) ui.attachStream('me', state.localStream, 'main');
    ui.showOwnCamState(state.me.cam);
    const ok = create ? await room.createRoom() : await room.joinRoom(el('inpCode').value);
    if (ok) {
      ui.setControlsState();
      ui.showOwnCamState(state.me.cam);
    }
  } catch (e) {
    toast('Ошибка запуска: ' + (e?.message || e), 'err');
  } finally {
    el('lobbySpinner').hidden = true;
  }
}

/* ============ КНОПКИ ЗВОНКА ============ */
function bindRoomControls() {
  on('btnMic', 'click', () => {
    if (media.toggleMic()) { ui.setControlsState(); room.broadcastMyState(); }
  });
  on('btnCam', 'click', () => {
    if (media.toggleCam()) {
      ui.setControlsState();
      ui.showOwnCamState(state.me.cam);
      room.broadcastMyState();
    }
  });
  on('btnScreen', 'click', () => room.toggleScreen().then(() => ui.setControlsState()));
  on('btnReact', 'click', () => { el('reactBar').hidden = !el('reactBar').hidden; });
  el('reactBar').querySelectorAll('button').forEach((b) => {
    b.addEventListener('click', () => { room.sendReaction(b.dataset.e); el('reactBar').hidden = true; });
  });
  on('btnLayout', 'click', () => {
    state.ui.layout = state.ui.layout === 'grid' ? 'spot' : 'grid';
    toast(state.ui.layout === 'spot' ? 'Крупный план' : 'Сетка', '', 1500);
    ui.updateLayout();
  });
  on('btnChat', 'click', () => toggleSide('chat'));
  on('btnPeople', 'click', () => toggleSide('people'));
  on('btnSideClose', 'click', () => toggleSide(null));
  on('tabChat', 'click', () => switchTab('chat'));
  on('tabPeople', 'click', () => switchTab('people'));
  on('btnLeave', 'click', () => room.leaveRoom());
  on('btnLeave2', 'click', () => room.leaveRoom());
  on('roomCode', 'click', async () => {
    const ok = await copyText(roomLink());
    toast(ok ? 'Ссылка скопирована — кидай её друзьям (например, в чат Steam)' : 'Не удалось скопировать', ok ? 'ok' : 'err');
  });

  on('chatForm', 'submit', (e) => {
    e.preventDefault();
    const inp = el('inpChat');
    const text = inp.value.trim();
    if (text) { room.sendChat(text); inp.value = ''; }
  });
}

function toggleSide(which) {
  const cur = state.ui.side;
  const side = el('side');
  if (which && cur !== which) {
    state.ui.side = which;
    side.hidden = false;
    switchTab(which);
  } else if (which && cur === which) {
    state.ui.side = null;
    side.hidden = true;
  } else {
    state.ui.side = null;
    side.hidden = true;
  }
  if (state.ui.side === 'chat') ui.clearUnread();
}

function switchTab(tab) {
  el('tabChat').classList.toggle('active', tab === 'chat');
  el('tabPeople').classList.toggle('active', tab === 'people');
  el('chatPanel').hidden = tab !== 'chat';
  el('peoplePanel').hidden = tab !== 'people';
  if (tab === 'chat') ui.clearUnread();
  if (tab === 'people') ui.updatePeopleList();
}

/* ============ МОДАЛКИ ============ */
function bindModals() {
  document.querySelectorAll('[data-close]').forEach((b) => {
    b.addEventListener('click', () => { el(b.dataset.close).hidden = true; });
  });
  document.querySelectorAll('.modal').forEach((m) => {
    m.addEventListener('pointerdown', (e) => { if (e.target === m) m.hidden = true; });
  });

  /* --- Приглашение --- */
  on('btnInvite', 'click', () => {
    el('invLink').value = roomLink();
    el('mInvite').hidden = false;
  });
  on('btnCopyInv', 'click', async () => {
    const ok = await copyText(el('invLink').value);
    toast(ok ? 'Скопировано!' : 'Не удалось скопировать', ok ? 'ok' : 'err');
  });
  on('btnShare', 'click', async () => {
    if (!navigator.share) { toast('Браузер не умеет «Поделиться» — скопируй ссылку', 'err'); return; }
    try {
      await navigator.share({ title: 'SteamCall', text: `${state.me.name} зовёт в звонок`, url: roomLink() });
    } catch {}
  });
  const sf = el('inpSteamFriend');
  sf.addEventListener('input', () => {
    const id = parseSteamId(sf.value);
    const btn = el('btnSteamInvite');
    const hint = el('steamParsed');
    if (id) {
      btn.disabled = false;
      hint.hidden = false;
      hint.innerHTML = `Друг найден: <a href="https://steamcommunity.com/profiles/${id}" target="_blank" rel="noopener">профиль ${id}</a>`;
    } else if (sf.value.trim()) {
      btn.disabled = true;
      hint.hidden = false;
      hint.textContent = 'Не похоже на SteamID64. Нужны цифры 7656… — ссылка /profiles/… или [U:1:…]';
    } else {
      btn.disabled = true;
      hint.hidden = true;
    }
  });
  on('btnSteamInvite', 'click', async () => {
    const id = parseSteamId(sf.value);
    if (!id) return;
    const ok = await copyText(inviteText());
    if (ok) toast('Приглашение скопировано! Вставь его в чат Steam (Ctrl+V)', 'ok', 6000);
    else toast('Скопируй вручную: ' + inviteText(), '', 8000);
    /* Открываем чат Steam с этим другом */
    try { location.href = `steam://friends/message/${id}`; } catch {}
  });

  /* --- Настройки --- */
  on('btnSettings', 'click', () => {
    el('setName').value = state.me.name;
    el('setAvatar').value = state.me.avatar;
    el('chkMirror').checked = !!state.settings.mirror;
    el('setTurnUrl').value = state.settings.turnUrl || '';
    el('setTurnUser').value = state.settings.turnUser || '';
    el('setTurnPass').value = state.settings.turnPass || '';
    el('setSigHost').value = state.settings.sigHost || '';
    media.populateDeviceSelects();
    el('mSettings').hidden = false;
  });
  on('btnRefreshDev', 'click', () => media.populateDeviceSelects());
  on('btnTestSound', 'click', () => media.testSound());
  on('btnSaveSettings', 'click', () => {
    state.me.name = el('setName').value.trim() || state.me.name;
    state.me.avatar = el('setAvatar').value.trim();
    state.settings.mirror = el('chkMirror').checked;
    state.settings.turnUrl = el('setTurnUrl').value.trim();
    state.settings.turnUser = el('setTurnUser').value.trim();
    state.settings.turnPass = el('setTurnPass').value.trim();
    state.settings.sigHost = el('setSigHost').value.trim();
    lsSet('sc_settings', state.settings);
    saveProfile();
    ui.setLocalMirror(state.settings.mirror);
    ui.updatePeopleList();
    el('mSettings').hidden = true;
    toast('Настройки сохранены', 'ok');
  });
  on('selMic', 'change', () => { if (el('selMic').value) media.switchDevice('mic', el('selMic').value); });
  on('selCam', 'change', () => { if (el('selCam').value) media.switchDevice('cam', el('selCam').value); });

  /* --- Потеря связи --- */
  on('btnRejoin', 'click', async () => {
    const code = state.room.code;
    room.leaveRoom(true);
    el('mLost').hidden = true;
    if (code) {
      el('inpCode').value = code;
      await startCall(false);
    }
  });
  on('btnToLobby', 'click', () => { room.hideLost(); room.leaveRoom(true); });
}

/* ============ ГОРЯЧИЕ КЛАВИШИ ============ */
function bindKeyboard() {
  document.addEventListener('keydown', (e) => {
    if (e.target.matches('input, select, textarea')) return;
    if (!state.room.code) return;
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    switch (e.code) {
      case 'KeyM': el('btnMic').click(); break;
      case 'KeyV': el('btnCam').click(); break;
      case 'KeyS': el('btnScreen').click(); break;
      case 'KeyC': toggleSide(state.ui.side === 'chat' ? null : 'chat'); break;
      case 'KeyF': fullscreenActive(); break;
      case 'KeyP': pinActive(); break;
    }
  });
}

function activeTileEl() {
  return document.querySelector('#spotMain .tile') || document.querySelector('.tile.demo') || document.querySelector('#grid .tile');
}
function fullscreenActive() {
  const t = activeTileEl();
  const fn = t?.requestFullscreen || t?.webkitRequestFullscreen;
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  else fn?.call(t);
}
function pinActive() {
  const t = activeTileEl();
  if (!t) return;
  const m = t.id.match(/^t-(.+)-(main|screen)$/);
  if (m) ui.togglePin(m[1]);
}
/* ===== КОНЕЦ ===== */
