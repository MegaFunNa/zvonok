/* ============================================================
   media.js — камеры, микрофоны, демка экрана, громкость
   ============================================================ */
import { state, toast, el } from './store.js';

/* ---------- AudioContext ---------- */
let actx = null;
export function getCtx() {
  if (!actx) {
    try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch { actx = null; }
  }
  if (actx && actx.state === 'suspended') actx.resume().catch(() => {});
  return actx;
}
/* Разблокировка автопроигрывания по первому клику */
export function unlockAudio() {
  getCtx();
  document.querySelectorAll('video[autoplay]').forEach((v) => v.play?.().catch(() => {}));
}

/* ---------- Громкость (0..200, >100 = усиление через WebAudio) ---------- */
const volMap = new WeakMap(); // video -> {gain}
export function setElVolume(video, v) {
  if (!video) return;
  const val = Math.max(0, Math.min(200, +v || 0)) / 100;
  const g = volMap.get(video);
  if (g) {
    /* элемент уже завязан в WebAudio-граф — рулим только гейном */
    try { video.muted = false; video.volume = 1; } catch {}
    g.gain.value = val;
    return;
  }
  try { video.muted = false; video.volume = Math.min(1, val); } catch {}
  if (val > 1) {
    const ctx = getCtx();
    if (!ctx) return;
    try {
      const src = ctx.createMediaElementSource(video);
      const gain = ctx.createGain();
      src.connect(gain).connect(ctx.destination);
      volMap.set(video, { gain });
      video.volume = 1;
      gain.gain.value = val;
    } catch {}
  }
}

/* ---------- Fallback-поток (тихий звук + чёрный кадр) ----------
   Нужен, чтобы войти в звонок без камеры/микрофона:
   в SDP всегда есть m-линии, и медиа-соединение корректно стартует. */
export function fallbackStream() {
  const tracks = [];
  try {
    const ctx = getCtx();
    if (ctx) {
      const dst = ctx.createMediaStreamDestination();
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      g.gain.value = 0;
      osc.connect(g).connect(dst);
      osc.start();
      const at = dst.stream.getAudioTracks()[0];
      if (at) tracks.push(at);
    }
  } catch {}
  try {
    const c = document.createElement('canvas');
    c.width = 320; c.height = 180;
    const cx = c.getContext('2d');
    cx.fillStyle = '#0c0f14';
    cx.fillRect(0, 0, 320, 180);
    const vt = c.captureStream(2).getVideoTracks()[0];
    if (vt) tracks.push(vt);
  } catch {}
  return new MediaStream(tracks);
}

/* ---------- Детектор уровня речи ---------- */
const watchers = new Map(); // key -> {ctx, analyser, buf, cb, last}
export function watchLevel(key, stream, cb) {
  if (!stream || !stream.getAudioTracks().length) return;
  const ctx = getCtx();
  if (!ctx) return;
  try {
    const src = ctx.createMediaStreamSource(stream);
    const an = ctx.createAnalyser();
    an.fftSize = 512;
    src.connect(an);
    const buf = new Uint8Array(an.frequencyBinCount);
    const w = { an, buf, cb, on: false, src };
    watchers.set(key, w);
    const loop = () => {
      if (!watchers.has(key)) return;
      an.getByteFrequencyData(buf);
      let sum = 0;
      for (let i = 2; i < buf.length; i++) sum += buf[i] * buf[i];
      const rms = Math.sqrt(sum / buf.length);
      const active = rms > 14;
      if (active !== w.on) { w.on = active; cb(active); }
      w.timer = setTimeout(loop, 180);
    };
    loop();
  } catch {}
}
export function stopWatchLevel(key) {
  const w = watchers.get(key);
  if (!w) return;
  clearTimeout(w.timer);
  try { w.src.disconnect(); } catch {}
  watchers.delete(key);
}

/* ---------- Локальный поток ---------- */
export async function initLocal() {
  const s = state.settings;
  const tryGet = async (video, audio) => {
    const c = {};
    if (video) c.video = s.camId ? { deviceId: { exact: s.camId }, width: { ideal: 1280 }, height: { ideal: 720 } } : { width: { ideal: 1280 }, height: { ideal: 720 } };
    if (audio) c.audio = s.micId
      ? { deviceId: { exact: s.micId }, echoCancellation: true, noiseSuppression: true }
      : { echoCancellation: true, noiseSuppression: true };
    return navigator.mediaDevices.getUserMedia(c);
  };
  try {
    state.localStream = await tryGet(true, true);
  } catch {
    try {
      state.localStream = await tryGet(false, true);
      state.me.cam = false;
      toast('Камера недоступна — заходишь только с микрофоном', '', 5000);
    } catch {
      try {
        state.localStream = await tryGet(true, false);
        state.me.mic = false;
        toast('Микрофон недоступен', '', 5000);
      } catch {
        state.localStream = fallbackStream();
        state.me.mic = false; state.me.cam = false;
        toast('Нет доступа к камере/микрофону — ты будешь только смотреть и писать в чат', 'err', 6000);
      }
    }
  }
  return state.localStream;
}

/* ---------- Микрофон / камера ---------- */
export function toggleMic() {
  const tr = state.localStream?.getAudioTracks()[0];
  if (!tr) { toast('Микрофона нет — разреши доступ и перезайди', 'err'); return false; }
  state.me.mic = !state.me.mic;
  tr.enabled = state.me.mic;
  return true;
}
export function toggleCam() {
  const tr = state.localStream?.getVideoTracks()[0];
  if (!tr) { toast('Камеры нет — разреши доступ и перезайди', 'err'); return false; }
  state.me.cam = !state.me.cam;
  tr.enabled = state.me.cam;
  return true;
}

/* ---------- Демка экрана ---------- */
export async function startScreen() {
  if (!navigator.mediaDevices?.getDisplayMedia) {
    toast('Браузер не умеет демонстрировать экран. В Chrome/Edge — умеет.', 'err', 6000);
    return null;
  }
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 30 },
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
    });
    state.screenStream = stream;
    state.sharing = true;
    const vt = stream.getVideoTracks()[0];
    if (vt) {
      vt.contentHint = 'detail';
      /* Пользователь нажал «Стоп» в браузерской плашке или завершил демку системно */
      vt.addEventListener('ended', () => {
        document.dispatchEvent(new CustomEvent('sc:stop-screen'));
      });
    }
    if (!stream.getAudioTracks().length) {
      toast('Звук не передаётся. Чтобы делиться звуком: выбери вкладку и включи галочку «Поделиться звуком вкладки»', '', 7000);
    }
    return stream;
  } catch (e) {
    if (e && e.name !== 'NotAllowedError') toast('Не получилось запустить демку: ' + e.message, 'err');
    return null;
  }
}

export function stopScreen(byTrackEnd = false) {
  const s = state.screenStream;
  if (s) s.getTracks().forEach((t) => { try { t.stop(); } catch {} });
  state.screenStream = null;
  state.sharing = false;
  return byTrackEnd;
}

/* ---------- Устройства ---------- */
export async function populateDeviceSelects() {
  if (!navigator.mediaDevices?.enumerateDevices) return;
  let devs = [];
  try { devs = await navigator.mediaDevices.enumerateDevices(); } catch { return; }
  const mics = devs.filter((d) => d.kind === 'audioinput');
  const cams = devs.filter((d) => d.kind === 'videoinput');
  const fill = (selId, list, cur, defLabel) => {
    const sel = el(selId);
    if (!sel) return;
    sel.innerHTML = list.length
      ? list.map((d) => `<option value="${d.deviceId}">${d.label || defLabel}</option>`).join('')
      : `<option value="">Нет устройств</option>`;
    if (cur && list.some((d) => d.deviceId === cur)) sel.value = cur;
  };
  fill('selMic', mics, state.settings.micId, 'Микрофон');
  fill('selCam', cams, state.settings.camId, 'Камера');
  return { mics, cams };
}

export async function switchDevice(kind, deviceId) {
  const isMic = kind === 'mic';
  try {
    const ns = await navigator.mediaDevices.getUserMedia(
      isMic
        ? { audio: { deviceId: { exact: deviceId }, echoCancellation: true, noiseSuppression: true } }
        : { video: { deviceId: { exact: deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } } }
    );
    const newTrack = isMic ? ns.getAudioTracks()[0] : ns.getVideoTracks()[0];
    if (state.localStream) {
      const old = isMic ? state.localStream.getAudioTracks()[0] : state.localStream.getVideoTracks()[0];
      if (old) { state.localStream.removeTrack(old); old.stop(); }
      state.localStream.addTrack(newTrack);
    } else {
      state.localStream = ns;
    }
    if (!newTrack.enabled) newTrack.enabled = true;
    state.settings[isMic ? 'micId' : 'camId'] = deviceId;
    /* ReplaceTrack на всех исходящих звонках */
    document.dispatchEvent(new CustomEvent('sc:replace-track', {
      detail: { kind: isMic ? 'audio' : 'video', track: newTrack },
    }));
    return true;
  } catch (e) {
    toast('Не удалось переключить устройство: ' + (e.message || ''), 'err');
    return false;
  }
}

/* ---------- Проверка звука ---------- */
export function testSound() {
  const ctx = getCtx();
  if (!ctx) { toast('Аудио недоступно', 'err'); return; }
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.frequency.value = 660;
  g.gain.setValueAtTime(0.001, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.05);
  g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
  o.connect(g).connect(ctx.destination);
  o.start();
  o.stop(ctx.currentTime + 0.85);
}
/* ===== КОНЕЦ ===== */
