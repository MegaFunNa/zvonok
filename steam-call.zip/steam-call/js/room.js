/* ============================================================
   room.js — PeerJS-комнаты: сигналинг, звонки, миграция хоста
   Архитектура:
   - код комнаты = 6 символов; peer-ID хоста = 'stmcl'+код
   - хост = «звезда» для чата/присутствия (data-каналы)
   - медиа (видео/звук/демка) — напрямую P2P между всеми (mesh)
   - если хост вышел — самый ранний участник перехватывает ID комнаты
   ============================================================ */
import { state, toast, uid, sleep, randCode } from './store.js';
import * as ui from './ui.js';
import * as media from './media.js';

const PREFIX = 'stmcl';
let memberDc = null;         // data-канал участника к хосту
const hostDcs = new Map();   // pid -> conn (режим хоста)
const lastSeen = new Map();  // pid -> ts (режим хоста)
let hbTimer = null, pruneTimer = null, lostTimer = null, joinTimeout = null;
let pongAt = 0;
let migrating = false, leaving = false, hostTakeover = false;
let joinTry = 0;
let pendingKeep = null;
const seenMsg = new Set();

const roomId = () => PREFIX + (state.room.code || '');
function userPacket() { return { name: state.me.name, avatar: state.me.avatar || '', steamId: state.me.steamId || '' }; }
function myEntry() { return { id: state.me.id, user: userPacket(), mic: state.me.mic, cam: state.me.cam, sharing: state.sharing, ts: state.room.ts }; }
function membersList() { return [myEntry(), ...[...state.room.members.values()].map((e) => ({ id: e.id, user: e.user, mic: e.mic, cam: e.cam, sharing: e.sharing, ts: e.ts }))]; }
function pruneSeen() { if (seenMsg.size > 300) { const it = seenMsg.values(); for (let i = 0; i < 100; i++) seenMsg.delete(it.next().value); } }

/* ---------- ICE/серверы ---------- */
function peerOptions() {
  const s = state.settings;
  const ice = [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: 'stun:stun.cloudflare.com:3478' },
  ];
  if (s.turnUrl) ice.push({ urls: s.turnUrl, username: s.turnUser || undefined, credential: s.turnPass || undefined });
  const o = { debug: 0, config: { iceServers: ice } };
  if (s.sigHost) {
    const h = s.sigHost.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (h) { o.host = h; o.secure = true; o.port = 443; o.path = '/'; }
  }
  return o;
}

/* ---------- Создание пира ---------- */
function initPeer(id, isHost) {
  const peer = new Peer(id || undefined, peerOptions());
  state.peer = peer;
  state.me.id = null;
  peer.on('open', (pid) => {
    state.me.id = pid;
    ui.setNetBadge(false);
    if (isHost) {
      state.room.isHost = true;
      state.room.hostId = pid;
      startPrune();
      if (hostTakeover) { hostTakeover = false; afterClaim(); }
    }
  });
  peer.on('connection', (conn) => onIncomingConn(conn));
  peer.on('call', (mc) => onIncomingCall(mc));
  peer.on('disconnected', () => {
    if (leaving) return;
    ui.setNetBadge(true);
    try { peer.reconnect(); } catch {}
  });
  peer.on('error', (err) => onPeerError(err, isHost));
  return peer;
}

function onPeerError(err, isHost) {
  const type = err && err.type;
  if (type === 'peer-unavailable') {
    if (state.room.joined) return; /* отдельный звонок не прошёл — не критично */
    if (joinTry < 3) {
      joinTry++;
      toast('Комната не отвечает… пробую ещё раз (' + joinTry + '/3)');
      retryJoin();
    } else failJoin('Комната не найдена. Проверь код или попроси свежую ссылку.');
  } else if (type === 'unavailable-id') {
    if (isHost && !state.room.joined && state.room.creating) {
      state.room.creating = false;
      toast('Код комнаты занят, генерирую новый…');
      createRoomRetry();
    } else if (hostTakeover || migrating) {
      becomeMemberAgain();
    }
  } else if (type === 'network' || type === 'server-error' || type === 'socket-error') {
    ui.setNetBadge(true);
    toast('Проблема с сигнальным сервером, переподключаюсь…', 'err');
  } else if (type === 'browser-incompatible') {
    toast('Браузер не поддерживает WebRTC — попробуй Chrome или Firefox', 'err', 8000);
  }
}

function waitPeerOpen(peer, ms = 12000) {
  return new Promise((res, rej) => {
    const to = setTimeout(() => rej(new Error('timeout')), ms);
    const ok = (id) => { clearTimeout(to); res(id); };
    const bad = (e) => { if (['unavailable-id', 'server-error', 'socket-error', 'browser-incompatible'].includes(e.type)) { clearTimeout(to); rej(e); } };
    peer.on('open', ok);
    peer.on('error', bad);
  });
}

/* ============================================================
   ВХОД В КОМНАТУ
   ============================================================ */
export async function createRoom() {
  let attempt = 0;
  while (attempt < 3) {
    attempt++;
    state.room.code = randCode(6);
    state.room.creating = true;
    state.room.ts = Date.now();
    const peer = initPeer(roomId(), true);
    try {
      await waitPeerOpen(peer);
      state.room.creating = false;
      state.room.joined = true;
      ui.showRoom();
      media.populateDeviceSelects();
      return true;
    } catch (e) {
      try { peer.destroy(); } catch {}
      if (e.type === 'unavailable-id') continue; /* код совпал — попробуем другой */
      failJoin('Не удалось подключиться к сигнальному серверу. Проверь интернет (и не блокирует ли его VPN/антибаннер).');
      return false;
    }
  }
  failJoin('Не получилось занять код комнаты, попробуй ещё раз');
  return false;
}

async function createRoomRetry() { await createRoom(); }

export async function joinRoom(code) {
  state.room.code = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!state.room.code || state.room.code.length < 4) { toast('Введи код комнаты', 'err'); return false; }
  joinTry = 0;
  const ok = await joinExisting();
  if (ok) { ui.showRoom(); media.populateDeviceSelects(); }
  return ok;
}

async function joinExisting() {
  state.room.ts = Date.now();
  state.room.isHost = false;
  const peer = initPeer(null, false);
  try { await waitPeerOpen(peer); } catch (e) { failJoin('Сигнальный сервер недоступен. Попробуй позже.'); return false; }
  connectToHost();
  return await new Promise((res) => {
    joinTimeout = setTimeout(() => { if (!state.room.joined) { failJoin('Не удалось подключиться: комната молчит (таймаут)'); res(false); } }, 16000);
    const iv = setInterval(() => { if (state.room.joined) { clearInterval(iv); res(true); } else if (!state.peer) { clearInterval(iv); res(false); } }, 200);
  });
}

async function retryJoin() {
  try { state.peer?.destroy(); } catch {}
  state.peer = null;
  await sleep(1500);
  if (leaving) return;
  joinExisting();
}

function connectToHost() {
  const conn = state.peer.connect(roomId(), {
    metadata: { role: 'join', user: userPacket(), mic: state.me.mic, cam: state.me.cam },
    reliable: true,
  });
  memberDc = conn;
  conn.on('data', (m) => { if (!state.room.isHost) onMemberData(m, conn); });
  conn.on('close', () => {
    if (!leaving && state.room.joined && !migrating && !state.room.isHost) onHostLost();
  });
}

function failJoin(msg) {
  clearTimeout(joinTimeout);
  try { state.peer?.destroy(); } catch {}
  state.peer = null;
  state.room.code = null; state.room.isHost = false; state.room.hostId = null;
  state.room.joined = false;
  toast(msg, 'err', 7000);
  ui.showLobby();
}

/* ============================================================
   УЧАСТНИКИ / ПРИСУТСТВИЕ
   ============================================================ */
function ensureEntry(pid, user) {
  if (!pid || pid === state.me.id) return null;
  let e = state.room.members.get(pid);
  if (!e) {
    e = {
      id: pid,
      user: user ? { name: user.name || 'Гость', avatar: user.avatar || '', steamId: user.steamId || '' } : { name: 'Гость' },
      mic: user ? user.mic !== false : true,
      cam: user ? user.cam !== false : true,
      sharing: false, ts: Date.now(), mcMain: null, mcScreen: null,
    };
    state.room.members.set(pid, e);
    ui.ensureParticipant({ pid, user: e.user, mic: e.mic, cam: e.cam, sharing: e.sharing, ts: e.ts });
  } else if (user) {
    e.user = { ...e.user, name: user.name || e.user.name, avatar: user.avatar || e.user.avatar, steamId: user.steamId || e.user.steamId };
    if (user.mic !== undefined) e.mic = user.mic !== false;
    if (user.cam !== undefined) e.cam = user.cam !== false;
  }
  return e;
}

function applyList(list) {
  if (!Array.isArray(list)) return;
  const ids = new Set(list.map((m) => m.id).filter((x) => x && x !== state.me.id));
  const added = [];
  for (const [pid, e] of [...state.room.members]) {
    if (!ids.has(pid)) {
      try { e.mcMain?.close(); } catch {}
      try { e.mcScreen?.close(); } catch {}
      media.stopWatchLevel(pid);
      state.room.members.delete(pid);
      ui.removeParticipant(pid);
    }
  }
  for (const m of list) {
    if (!m.id || m.id === state.me.id) continue;
    let e = state.room.members.get(m.id);
    if (!e) {
      e = { id: m.id, user: m.user || { name: 'Гость' }, mic: m.mic !== false, cam: m.cam !== false, sharing: !!m.sharing, ts: m.ts || Date.now(), mcMain: null, mcScreen: null };
      state.room.members.set(m.id, e);
      added.push(m.id);
    } else {
      Object.assign(e, { mic: m.mic !== false, cam: m.cam !== false, sharing: !!m.sharing, ts: m.ts || e.ts });
      if (m.user) e.user = { ...e.user, ...m.user };
    }
    ui.ensureParticipant({ pid: m.id, user: e.user, mic: e.mic, cam: e.cam, sharing: e.sharing, ts: e.ts });
  }
  /* я делюсь экраном и появился новый участник → звоню ему демкой */
  if (state.sharing) for (const id of added) callPeer(id, 'screen');
}

function applyState(pid, m) {
  if (pid === state.me.id) return;
  const e = state.room.members.get(pid);
  if (!e) return;
  e.mic = m.mic !== false; e.cam = m.cam !== false;
  ui.setParticipantState(pid, { mic: e.mic, cam: e.cam });
}

function applyScreen(pid, on) {
  if (pid === state.me.id) return;
  const e = state.room.members.get(pid);
  if (!e) return;
  e.sharing = !!on;
  ui.setSharing(pid, !!on);
}

/* ---------- Входящие data-соединения ---------- */
function onIncomingConn(conn) {
  const role = conn.metadata?.role;
  conn.on('data', (m) => { if (state.room.isHost) onHostData(conn, m); else onMemberData(m, conn); });
  if (state.room.isHost && role === 'join') {
    conn.on('open', () => hostAddMember(conn));
    conn.on('close', () => hostDropMember(conn.peer));
  } else if (!state.room.isHost && conn.peer === roomId()) {
    conn.on('open', () => { memberDc = conn; });
    conn.on('close', () => { if (!leaving && !migrating) onHostLost(); });
  }
}

/* ---------- Хост: добавление/удаление ---------- */
function hostAddMember(conn) {
  const meta = conn.metadata || {};
  const pid = conn.peer;
  let entry = state.room.members.get(pid);
  if (!entry) {
    entry = {
      id: pid,
      user: meta.user || { name: 'Гость' },
      mic: meta.mic !== false, cam: meta.cam !== false,
      sharing: false, ts: Date.now(), mcMain: null, mcScreen: null,
    };
    state.room.members.set(pid, entry);
    ui.ensureParticipant({ pid, user: entry.user, mic: entry.mic, cam: entry.cam, sharing: false, ts: entry.ts });
    ui.sysMsg(`${entry.user.name} заходит в звонок`);
  }
  hostDcs.set(pid, conn);
  lastSeen.set(pid, Date.now());
  try { conn.send({ t: 'welcome', hostId: state.me.id, yourTs: entry.ts, members: membersList() }); } catch {}
  syncAll();
  /* если я сейчас делюсь экраном — сразу звоню новичку демкой */
  if (state.sharing) callPeer(pid, 'screen');
}

function hostDropMember(pid) {
  const e = state.room.members.get(pid);
  if (!e) return;
  try { e.mcMain?.close(); } catch {}
  try { e.mcScreen?.close(); } catch {}
  media.stopWatchLevel(pid);
  state.room.members.delete(pid);
  const dc = hostDcs.get(pid);
  if (dc) { try { dc.close(); } catch {} hostDcs.delete(pid); }
  lastSeen.delete(pid);
  ui.removeParticipant(pid);
  ui.sysMsg(`${e.user.name} покинул звонок`);
  syncAll();
}

function broadcast(msg, exceptId) {
  for (const [pid, dc] of hostDcs) {
    if (pid === exceptId) continue;
    try { if (dc.open) dc.send(msg); } catch {}
  }
}
function syncAll() { broadcast({ t: 'sync', members: membersList() }); }

function onHostData(conn, m) {
  if (!m || !m.t) return;
  const pid = conn.peer;
  switch (m.t) {
    case 'ping':
      lastSeen.set(pid, Date.now());
      try { conn.send({ t: 'pong', ts: m.ts }); } catch {}
      break;
    case 'chat':
      if (seenMsg.has(m.msg?.id)) break;
      seenMsg.add(m.msg.id); pruneSeen();
      ui.addChat(m.msg, false);
      broadcast({ t: 'chat', msg: m.msg }, pid);
      break;
    case 'reaction': {
      const e = state.room.members.get(pid);
      const nm = e?.user?.name || 'Гость';
      ui.spawnReaction(m.emoji, nm);
      broadcast({ t: 'reaction', emoji: m.emoji, name: nm }, pid);
      break;
    }
    case 'state':
      applyState(pid, m);
      broadcast({ t: 'state', id: pid, mic: m.mic, cam: m.cam }, pid);
      break;
    case 'screen':
      applyScreen(pid, m.on);
      broadcast({ t: 'screen', id: pid, on: m.on }, pid);
      break;
    case 'leave':
      hostDropMember(pid);
      break;
  }
}

function startPrune() {
  stopPrune();
  pruneTimer = setInterval(() => {
    const now = Date.now();
    for (const [pid, ts] of lastSeen) {
      if (now - ts > 24000) hostDropMember(pid);
    }
  }, 6000);
}
function stopPrune() { if (pruneTimer) { clearInterval(pruneTimer); pruneTimer = null; } }

/* ---------- Участник: сообщения от хоста ---------- */
function onMemberData(m, conn) {
  if (!m || !m.t) return;
  switch (m.t) {
    case 'welcome': onWelcome(m); break;
    case 'sync': if (state.room.joined) applyList(m.members); break;
    case 'chat':
      if (!seenMsg.has(m.msg?.id)) { seenMsg.add(m.msg.id); pruneSeen(); ui.addChat(m.msg, false); }
      break;
    case 'reaction': ui.spawnReaction(m.emoji, m.name); break;
    case 'state': applyState(m.id, m); break;
    case 'screen': applyScreen(m.id, m.on); break;
    case 'pong': pongAt = Date.now(); break;
    case 'hostmoved': onHostMoved(m, conn); break;
    case 'hostleft': onHostLost(); break;
  }
}

function onWelcome(m) {
  clearTimeout(joinTimeout);
  state.room.joined = true;
  state.room.hostId = m.hostId;
  state.room.ts = m.yourTs || Date.now();
  migrating = false;
  memberDc = memberDc || null;
  applyList(m.members);
  for (const e of state.room.members.values()) callPeer(e.id, 'main');
  startHeartbeat();
  ui.setNetBadge(false);
  ui.sysMsg(`Ты в комнате ${state.room.code}. Жми «Пригласить» и кидай ссылку друзьям!`);
}

function startHeartbeat() {
  stopHeartbeat();
  pongAt = Date.now();
  hbTimer = setInterval(() => {
    if (migrating || leaving || state.room.isHost) return;
    if (memberDc && memberDc.open) { try { memberDc.send({ t: 'ping', ts: Date.now() }); } catch {} }
    if (Date.now() - pongAt > 18000) onHostLost();
  }, 5000);
}
function stopHeartbeat() { if (hbTimer) { clearInterval(hbTimer); hbTimer = null; } }

/* ============================================================
   МЕДИА-ЗВОНКИ (mesh)
   ============================================================ */
function onIncomingCall(mc) {
  if (!state.room.code) return;
  const meta = mc.metadata || {};
  const type = meta.type === 'screen' ? 'screen' : 'main';
  const pid = mc.peer;
  if (!pid || pid === state.me.id) return;
  const entry = ensureEntry(pid, meta.user);
  if (!entry) return;
  const key = type === 'screen' ? 'mcScreen' : 'mcMain';
  if (entry[key] && entry[key] !== mc) { try { entry[key].close(); } catch {} }
  entry[key] = mc;
  try {
    if (type === 'screen') mc.answer(new MediaStream());
    else mc.answer(state.localStream || media.fallbackStream());
  } catch (e) {
    toast('Не удалось ответить на входящий поток: ' + (e.message || e), 'err');
  }
  wireMc(mc, pid, type, true);
}

export function callPeer(pid, type) {
  if (!state.peer || !pid || pid === state.me.id) return null;
  const entry = ensureEntry(pid);
  if (!entry) return null;
  let stream = type === 'screen' ? state.screenStream : state.localStream;
  if (!stream) stream = media.fallbackStream();
  const key = type === 'screen' ? 'mcScreen' : 'mcMain';
  if (entry[key]) { try { entry[key].close(); } catch {} }
  let mc = null;
  try {
    mc = state.peer.call(pid, stream, { metadata: { type, user: userPacket(), mic: state.me.mic, cam: state.me.cam } });
  } catch { return null; }
  if (!mc) return null;
  entry[key] = mc;
  wireMc(mc, pid, type, false);
  return mc;
}

function wireMc(mc, pid, type, incoming) {
  mc.on('stream', (remote) => {
    ui.attachStream(pid, remote, type);
    if (type === 'main') {
      media.stopWatchLevel(pid);
      media.watchLevel(pid, remote, (act) => ui.setSpeaking(pid, act));
    }
    if (!incoming) tuneSenders(mc, type);
  });
  mc.on('close', () => ui.setNetState(pid, type, false));
  mc.on('error', () => ui.setNetState(pid, type, false));
}

function tuneSenders(mc, type) {
  try {
    const pc = mc.peerConnection;
    if (!pc) return;
    for (const s of pc.getSenders()) {
      if (!s.track) continue;
      const p = s.getParameters ? (s.getParameters() || {}) : {};
      p.encodings = p.encodings && p.encodings.length ? p.encodings : [{}];
      p.encodings[0].maxBitrate = type === 'screen' ? 3500000 : 1400000;
      if (type === 'screen') p.encodings[0].degradationPreference = 'maintain-resolution';
      try { s.setParameters(p).catch?.(() => {}); } catch {}
    }
  } catch {}
}

/* Замена трека при переключении устройства */
document.addEventListener('sc:replace-track', (ev) => {
  const { kind, track } = ev.detail || {};
  for (const e of state.room.members.values()) {
    const mc = e.mcMain;
    if (!mc?.peerConnection) continue;
    try {
      for (const s of mc.peerConnection.getSenders()) {
        if (s.track && s.track.kind === kind) s.replaceTrack(track).catch(() => {});
      }
    } catch {}
  }
});

/* ============================================================
   ДЕМКА ЭКРАНА
   ============================================================ */
export async function toggleScreen() {
  if (state.sharing) { stopScreenFlow(); return; }
  const s = await media.startScreen();
  if (!s) return;
  ui.setSharing('me', true);
  ui.attachStream('me', s, 'screen');
  ui.updateLayout();
  sendScreenState(true);
  for (const pid of state.room.members.keys()) callPeer(pid, 'screen');
  ui.sysMsg('Демка экрана запущена');
}

function stopScreenFlow() {
  if (!state.sharing) return;
  media.stopScreen();
  ui.setSharing('me', false);
  for (const e of state.room.members.values()) {
    try { e.mcScreen?.close(); } catch {}
    e.mcScreen = null;
  }
  sendScreenState(false);
  ui.sysMsg('Демка экрана остановлена');
}

document.addEventListener('sc:stop-screen', () => stopScreenFlow());

function sendScreenState(on) {
  if (state.room.isHost) broadcast({ t: 'screen', id: state.me.id, on });
  else if (memberDc && memberDc.open) { try { memberDc.send({ t: 'screen', on }); } catch {} }
}

/* ============================================================
   ЧАТ / РЕАКЦИИ / СОСТОЯНИЕ
   ============================================================ */
export function sendChat(text) {
  if (!text || !state.room.code) return;
  const msg = { id: uid(), from: state.me.id, name: state.me.name, avatar: state.me.avatar || '', text, ts: Date.now() };
  ui.addChat(msg, true);
  seenMsg.add(msg.id); pruneSeen();
  if (state.room.isHost) broadcast({ t: 'chat', msg });
  else if (memberDc && memberDc.open) { try { memberDc.send({ t: 'chat', msg }); } catch {} }
}

export function sendReaction(emoji) {
  if (!state.room.code) return;
  ui.spawnReaction(emoji, null);
  if (state.room.isHost) broadcast({ t: 'reaction', emoji, name: state.me.name });
  else if (memberDc && memberDc.open) { try { memberDc.send({ t: 'reaction', emoji }); } catch {} }
}

export function broadcastMyState() {
  if (!state.room.code) return;
  if (state.room.isHost) broadcast({ t: 'state', id: state.me.id, mic: state.me.mic, cam: state.me.cam });
  else if (memberDc && memberDc.open) {
    try { memberDc.send({ t: 'state', mic: state.me.mic, cam: state.me.cam }); } catch {}
  }
  ui.setParticipantState('me', { mic: state.me.mic, cam: state.me.cam });
}

/* ============================================================
   МИГРАЦИЯ ХОСТА
   ============================================================ */
function onHostLost() {
  if (migrating || leaving || !state.room.joined || state.room.isHost) return;
  migrating = true;
  stopHeartbeat();
  ui.setNetBadge(true);
  ui.sysMsg('Связь с хостом потеряна — выбираем нового…');
  const others = [...state.room.members.values()].filter((e) => e.id !== state.room.hostId);
  /* кто захватывает ID комнаты: самый ранний участник;
     если никого не осталось — я сам (комната продолжит жить) */
  const cand = others.length ? others.reduce((a, b) => (a.ts <= b.ts ? a : b)) : null;
  if (!cand || cand.id === state.me.id) {
    setTimeout(() => { if (migrating && !leaving) claimRoom(); }, 1200 + Math.random() * 2000);
  } else {
    if (lostTimer) clearTimeout(lostTimer);
    lostTimer = setTimeout(() => { if (migrating) showLost(); }, 26000);
  }
}

async function claimRoom() {
  if (leaving) return;
  const keep = [...state.room.members.values()]
    .filter((e) => e.id !== state.room.hostId)
    .map((e) => ({ id: e.id, user: e.user, mic: e.mic, cam: e.cam, sharing: e.sharing, ts: e.ts }));
  pendingKeep = keep;
  try { state.peer?.destroy(); } catch {}
  state.peer = null;
  await sleep(700);
  if (leaving) return;
  hostTakeover = true;
  initPeer(roomId(), true);
}

function afterClaim() {
  migrating = false;
  if (lostTimer) clearTimeout(lostTimer);
  state.room.hostId = state.me.id;
  ui.setNetBadge(false);
  const keep = pendingKeep || [];
  pendingKeep = null;
  /* выкидываем старого хоста и всех, кто не дожил до захвата */
  const keepIds = new Set(keep.map((m) => m.id));
  for (const [pid, e] of [...state.room.members]) {
    if (!keepIds.has(pid)) {
      try { e.mcMain?.close(); } catch {}
      try { e.mcScreen?.close(); } catch {}
      media.stopWatchLevel(pid);
      state.room.members.delete(pid);
      ui.removeParticipant(pid);
    }
  }
  for (const m of keep) ensureEntry(m.id, m.user);
  for (const m of keep) {
    const conn = state.peer.connect(m.id, { metadata: { role: 'takeover', user: userPacket() }, reliable: true });
    hostDcs.set(m.id, conn);
    lastSeen.set(m.id, Date.now());
    conn.on('open', () => { try { conn.send({ t: 'hostmoved', members: membersList() }); } catch {} });
    conn.on('data', (d) => onHostData(conn, d));
    conn.on('close', () => hostDropMember(m.id));
  }
  for (const m of keep) {
    callPeer(m.id, 'main');
    if (state.sharing) callPeer(m.id, 'screen');
  }
  startPrune();
  ui.sysMsg('Комната восстановлена — теперь ты хост');
  toast('Комната восстановлена, ты хост', 'ok');
  ui.setControlsState();
  ui.updateRoombar();
}

function onHostMoved(m, conn) {
  migrating = false;
  if (lostTimer) clearTimeout(lostTimer);
  state.room.hostId = conn.peer;
  memberDc = conn;
  startHeartbeat();
  ui.setNetBadge(false);
  applyList(m.members);
  ui.sysMsg('Комната восстановлена');
}

/* Захват не удался (старый хост жив) — входим обычным участником */
function becomeMemberAgain() {
  hostTakeover = false;
  migrating = false;
  toast('Хост на месте — переподключаюсь как участник…');
  try { state.peer?.destroy(); } catch {}
  state.peer = null;
  state.room.isHost = false;
  state.room.joined = false;
  joinTry = 0;
  joinExisting();
}

function showLost() {
  const mdl = document.getElementById('mLost');
  if (mdl) mdl.hidden = false;
}
export function hideLost() {
  const mdl = document.getElementById('mLost');
  if (mdl) mdl.hidden = true;
}

/* ============================================================
   ВЫХОД
   ============================================================ */
export function leaveRoom(silent = false) {
  if (!state.room.code) return;
  leaving = true;
  try {
    if (state.room.isHost) broadcast({ t: 'hostleft' });
    else if (memberDc && memberDc.open) memberDc.send({ t: 'leave' });
  } catch {}
  stopHeartbeat(); stopPrune();
  if (lostTimer) clearTimeout(lostTimer);
  clearTimeout(joinTimeout);
  for (const e of state.room.members.values()) {
    try { e.mcMain?.close(); } catch {}
    try { e.mcScreen?.close(); } catch {}
  }
  media.stopWatchLevel('me');
  for (const pid of state.room.members.keys()) media.stopWatchLevel(pid);
  try { state.peer?.destroy(); } catch {}
  media.stopScreen();
  if (state.localStream) state.localStream.getTracks().forEach((t) => { try { t.stop(); } catch {} });
  state.peer = null; state.localStream = null; state.screenStream = null; state.sharing = false;
  state.room.code = null; state.room.isHost = false; state.room.hostId = null;
  state.room.joined = false; state.room.members.clear();
  memberDc = null; hostDcs.clear(); lastSeen.clear();
  migrating = false; leaving = false; hostTakeover = false; pendingKeep = null; joinTry = 0;
  hideLost();
  ui.resetRoomUI();
  ui.showLobby();
  if (!silent) toast('Ты вышел из звонка', 'ok');
}
/* ===== КОНЕЦ ===== */
